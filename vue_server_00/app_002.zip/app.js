//vue_server_00/app.js
//1:复制服务器端模块
//2:引入第三方模块
//  mysql/express/
const mysql = require("mysql");
const express = require("express");


//3:创建连接池
const pool = mysql.createPool({
  host:"127.0.0.1",
  user:"root",
  password:"",
  database:"xz"
});
//4:创建express对象
var server = express(); 

//app.js 录一段跨域配置
const cors = require("cors");
server.use(cors({
   origin:["http://127.0.0.1:8080",
   "http://localhost:8080"],
   credentials:true
}))

//5:绑定监听端口 3000
server.listen(3000);
//5.1:指定静态目录.保存图片资源
//    项目中所有图片都需要保存在服务器端
//    重启动服务器 
server.use(express.static("public"));

//6:处理用户登录请求
server.get("/login",(req,res)=>{
  //6.1:获取参数
  var name = req.query.name;
  var pwd = req.query.pwd;
  //6.2:创sql
  var sql = "SELECT id FROM xz_login";
  sql+=" WHERE name = ? AND pwd=md5(?)";
  //6.3:执行sql
  pool.query(sql,[name,pwd],(err,result)=>{
     if(err)throw err;
     //6.4:获取返回结果
     //6.5:判断结果返回 登录成功或者失败
     if(result.length==0){
       res.send({code:-1,msg:"用户名或密码有误"});
     }else{
       res.send({code:1,msg:"登录成功"})
     }
  });
});     

//7:功能二:商品列表  分页 56~108 app.zip
server.get("/getGoodList",(req,res)=>{
  //1:获取二个参数,只要分页功能
  //  pno      页码
  //  pageSize 页大小
  var pno = req.query.pno;
  var pageSize = req.query.pageSize;
  //1.1:为参数设置默认值
  if(!pno){
    pno = 1;
  }
  if(!pageSize){
   pageSize = 4;
  }
  //1.1:创建变量保存发送给客户端数据
  var obj = {code:1};
  //1.2:创建变量保存进度
  var progress = 0;

  //2:创建一条sql语句
  var sql =" SELECT lid,lname,price";
      sql+=" FROM xz_laptop";
      sql+=" LIMIT ?,?";
  //2.1:创建一个变量offset 起始行数
  var offset = (pno-1)*pageSize; 
  //2.2:创建一个变量ps     一页数据
  var ps = parseInt(pageSize);
  //3:执行sql语句
  pool.query(sql,[offset,ps],(err,result)=>{
    if(err)throw err;
    progress+=50;
    obj.data = result;
    //4:获取数据库返回结果
    //5:发送数据+不再发送数据
    //res.send({code:1,data:result});
    if(progress==100){
     res.send(obj);
    }
  })
  //6:计算总页数
  //6.1:创建sql查询总记录数
  var sql =" SELECT count(lid) AS c FROM";
      sql+=" xz_laptop";
  pool.query(sql,(err,result)=>{
    //result [{id:1,name:"tom"},{id:2}]
    //result [{c:11}]
    //result[0].c
    if(err)throw err;
    progress+=50;
    var pc = Math.ceil(result[0].c/pageSize);
    obj.pageCount = pc;
    if(progress==100){
      res.send(obj)
    }
  });    
  //6.2:计算总页数
});


//功能三:学子商城首页轮播图114~128  14:18
//1:将轮播保存服务器端 
//   public/img/banner1.png
//2:接收客户端发送请求 /imglist
server.get("/imglist",(req,res)=>{
  //3:创建数据发送客户端
  var rows = [
    {id:1,img_url:"http://127.0.0.1:3000/img/banner1.png"},
    {id:2,img_url:"http://127.0.0.1:3000/img/banner2.png"},
    {id:3,img_url:"http://127.0.0.1:3000/img/banner3.png"},
    {id:4,img_url:"http://127.0.0.1:3000/img/banner4.png"},
];
     res.send({code:1,data:rows})
})

//16:50
//功能四:学子商城--新闻列表 1 2 3
//http://127.0.0.1:3000/newslist
server.get("/newslist",(req,res)=>{
  //1:参数 pno pageSize
  var pno = req.query.pno;//页码 1 2 3
  var pageSize = req.query.pageSize;//页大小
  //1.1设置默认值
  if(!pno){
    pno = 1;
  }
  if(!pageSize){
    pageSize = 6;
  }
  //2:sql
  var sql = "SELECT id,title,ctime,point,img_url";
  sql+=" FROM xz_news LIMIT ?,?";
  var offset = (pno-1)*pageSize;
  pageSize = parseInt(pageSize);
  pool.query(sql,[offset,pageSize],(err,result)=>{
      if(err)throw err;
      res.send({code:1,data:result});
  })
  //3:json
})


//功能五:查询购物车列表  157~169
server.get("/getCart",(req,res)=>{
  //1:参数 uid 当前登录用户编号
  var uid = 2;
  //2:sql
  var sql = "SELECT id,lname,price,count";
  sql+=" FROM xz_cart";
  sql+=" WHERE uid = ?"
  //3:json
  pool.query(sql,[uid],(err,result)=>{
     if(err)throw err;
     res.send({code:1,data:result})
  });
});